#!/bin/sh

cd /c/pillow && /mingw32/$EXECUTABLE setup.py install
