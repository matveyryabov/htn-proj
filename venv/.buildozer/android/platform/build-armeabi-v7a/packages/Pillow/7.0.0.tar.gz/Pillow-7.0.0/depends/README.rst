Depends
=======

``install_openjpeg.sh``, ``install_webp.sh``, ``install_imagequant.sh``,
``install_raqm.sh`` and  ``install_raqm_cmake.sh`` can be used to download,
build & install non-packaged dependencies; useful for testing with Travis CI.

``install_extra_test_images.sh`` can be used to install additional test images
that are used for Travis CI and AppVeyor.
